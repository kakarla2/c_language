#include<stdio.h>
main( )
{
	print("hello");
	return0
}
